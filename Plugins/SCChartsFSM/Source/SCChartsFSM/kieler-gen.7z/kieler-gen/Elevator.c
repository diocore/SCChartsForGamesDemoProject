/*
 * Automatically generated C code by
 * KIELER SCCharts - The Key to Efficient Modeling
 *
 * http://rtsys.informatik.uni-kiel.de/kieler
 */
#include <stdio.h>
#include "Elevator.h"

static inline void Elevator_region__EA_Entry_state__EA_Done(Elevator_region__EA_EntryContext *context) {
  context->threadStatus = TERMINATED;
}

static inline void Elevator_region__EA_Entry_state__EA_Init(Elevator_region__EA_EntryContext *context) {
  context->iface->mooving = 0;
  context->delayedEnabled = 0;
  context->activeState = __EA_MAIN;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_state__EA_Exit3(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context *context) {
  if (context->delayedEnabled && (context->iface->targetFloor == context->iface->currecntFloor)) {
    context->iface->_taken_transitions[6] += 1;
    context->delayedEnabled = 0;
    context->activeState = IDLE;
  } else {
    context->threadStatus = READY;
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_state__EA_Exit2(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context *context) {
  if (context->delayedEnabled && (context->iface->targetFloor == context->iface->currecntFloor)) {
    context->iface->_taken_transitions[5] += 1;
    context->delayedEnabled = 0;
    context->activeState = IDLE;
  } else {
    context->threadStatus = READY;
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_state__EA_Init(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context *context) {
  context->iface->_taken_transitions[0] = 0;
  context->iface->_taken_transitions[1] = 0;
  context->iface->_taken_transitions[2] = 0;
  context->iface->_taken_transitions[3] = 0;
  context->iface->_taken_transitions[4] = 0;
  context->iface->_taken_transitions[5] = 0;
  context->iface->_taken_transitions[6] = 0;
  context->delayedEnabled = 0;
  context->activeState = IDLE;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_state_AC(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context *context) {
  if (context->iface->_Elevator_local__Atrig) {
    context->iface->_taken_transitions[0] += 1;
    context->delayedEnabled = 0;
    context->activeState = MOVINGUP;
  } else {
    context->iface->_taken_transitions[1] += 1;
    context->delayedEnabled = 0;
    context->activeState = MOVINGDOWN;
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry_state__EA_C5(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_EntryContext *context) {
  context->iface->moveDown |= 1;
  context->delayedEnabled = 0;
  context->activeState = __EA_DONE9;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry_state__EA_C4(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_EntryContext *context) {
  context->iface->stateID = 4;
  context->delayedEnabled = 0;
  context->activeState = __EA_C5;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry_state__EA_Done(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_EntryContext *context) {
  context->threadStatus = TERMINATED;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry_state__EA_Init(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_EntryContext *context) {
  context->iface->down = 0;
  context->delayedEnabled = 0;
  context->activeState = __EA_C4;
}

static void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_EntryContext *context) {
  while (context->threadStatus == RUNNING) {
    switch (context->activeState) {
      case __EA_INIT8:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry_state__EA_Init(context);
                break;
      
      case __EA_DONE9:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry_state__EA_Done(context);
                break;
      
      case __EA_C4:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry_state__EA_C4(context);
                break;
      
      case __EA_C5:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry_state__EA_C5(context);
                break;
      
    }
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context *context) {

  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry.activeState = __EA_INIT8;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry.delayedEnabled = 0;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry.threadStatus = READY;
  context->activeState = MOVINGDOWNRUNNING;
}


static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_running(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context *context) {

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry.threadStatus != TERMINATED) {
    context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry.threadStatus = RUNNING;
  }
  

  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry(&context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry);

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry.threadStatus == TERMINATED) {
    context->delayedEnabled = 0;
    context->activeState = __EA_EXIT3;
  } else {
  
      context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry.delayedEnabled = 1;
    context->threadStatus = READY;
  }

}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry_state__EA_C3(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_EntryContext *context) {
  context->iface->moveUp |= 1;
  context->delayedEnabled = 0;
  context->activeState = __EA_DONE7;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry_state__EA_C2(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_EntryContext *context) {
  context->iface->stateID = 3;
  context->delayedEnabled = 0;
  context->activeState = __EA_C3;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry_state__EA_Done(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_EntryContext *context) {
  context->threadStatus = TERMINATED;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry_state__EA_Init(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_EntryContext *context) {
  context->iface->up = 0;
  context->delayedEnabled = 0;
  context->activeState = __EA_C2;
}

static void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_EntryContext *context) {
  while (context->threadStatus == RUNNING) {
    switch (context->activeState) {
      case __EA_INIT6:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry_state__EA_Init(context);
                break;
      
      case __EA_DONE7:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry_state__EA_Done(context);
                break;
      
      case __EA_C2:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry_state__EA_C2(context);
                break;
      
      case __EA_C3:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry_state__EA_C3(context);
                break;
      
    }
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context *context) {

  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry.activeState = __EA_INIT6;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry.delayedEnabled = 0;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry.threadStatus = READY;
  context->activeState = MOVINGUPRUNNING;
}


static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_running(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context *context) {

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry.threadStatus != TERMINATED) {
    context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry.threadStatus = RUNNING;
  }
  

  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry(&context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry);

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry.threadStatus == TERMINATED) {
    context->delayedEnabled = 0;
    context->activeState = __EA_EXIT2;
  } else {
  
      context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry.delayedEnabled = 1;
    context->threadStatus = READY;
  }

}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_C1(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1Context *context) {
  context->iface->_Elevator_local__Atrig1 = 0;
  context->delayedEnabled = 0;
  context->activeState = __EA_MAIN1;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_C(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1Context *context) {
  context->iface->_Elevator_local__Atrig = 0;
  context->delayedEnabled = 0;
  context->activeState = __EA_C1;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Done(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1Context *context) {
  context->threadStatus = TERMINATED;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Init(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1Context *context) {
  context->iface->_Elevator_local__Tterm = 0;
  context->delayedEnabled = 0;
  context->activeState = __EA_C;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl_state_ADone(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrlContext *context) {
  context->threadStatus = TERMINATED;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl_state_ARun(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrlContext *context) {
  if (context->delayedEnabled && (context->iface->up && context->iface->_Elevator_local__Tterm)) {
    context->iface->_Elevator_local__Atrig = 1;
    context->delayedEnabled = 0;
    context->activeState = _ADONE;
  } else if (context->delayedEnabled && (context->iface->down && context->iface->_Elevator_local__Tterm)) {
    context->iface->_Elevator_local__Atrig1 = 1;
    context->delayedEnabled = 0;
    context->activeState = _ADONE;
  } else {
    context->threadStatus = READY;
  }
}

static void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrlContext *context) {
  while (context->threadStatus == RUNNING) {
    switch (context->activeState) {
      case _ARUN:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl_state_ARun(context);
                break;
      
      case _ADONE:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl_state_ADone(context);
                break;
      
    }
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_state__EA_Exit1(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1Context *context) {
  if (context->delayedEnabled && (!context->iface->doorOpen)) {
    context->iface->_taken_transitions[4] += 1;
    context->iface->_Elevator_local__Tterm = 1;
    context->delayedEnabled = 0;
    context->activeState = RDYFORTAKEOFF1;
  } else if (context->iface->_Elevator_local__Atrig || context->iface->_Elevator_local__Atrig1) {
    context->delayedEnabled = 0;
    context->activeState = RDYFORTAKEOFF1;
  } else {
    context->threadStatus = READY;
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_state__EA_Exit(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1Context *context) {
  if (context->delayedEnabled && (context->iface->doorOpen)) {
    context->iface->_taken_transitions[2] += 1;
    context->delayedEnabled = 0;
    context->activeState = WAIT;
  } else if (context->delayedEnabled && (context->iface->_Elevator_local__Atrig || context->iface->_Elevator_local__Atrig1)) {
    context->delayedEnabled = 0;
    context->activeState = RDYFORTAKEOFF1;
  } else {
    context->threadStatus = READY;
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateRdyFortakeoff1(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1Context *context) {
  context->threadStatus = TERMINATED;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry_state__EA_Done(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_EntryContext *context) {
  context->threadStatus = TERMINATED;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry_state__EA_Init(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_EntryContext *context) {
  context->iface->stateID = 2;
  context->delayedEnabled = 0;
  context->activeState = __EA_DONE3;
}

static void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_EntryContext *context) {
  while (context->threadStatus == RUNNING) {
    switch (context->activeState) {
      case __EA_INIT2:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry_state__EA_Init(context);
                break;
      
      case __EA_DONE3:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry_state__EA_Done(context);
                break;
      
    }
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1Context *context) {

  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry.activeState = __EA_INIT2;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry.delayedEnabled = 0;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry.threadStatus = READY;
  context->activeState = CLOSEDOORSRUNNING;
}


static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_running(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1Context *context) {

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry.threadStatus != TERMINATED) {
    context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry.threadStatus = RUNNING;
  }
  

  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry(&context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry);

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry.threadStatus == TERMINATED) {
    context->delayedEnabled = 0;
    context->activeState = __EA_EXIT1;
  } else {
  
      context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry.delayedEnabled = 1;
    context->threadStatus = READY;
  }

}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateWait(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1Context *context) {
  if (context->delayedEnabled && (context->iface->down || context->iface->up)) {
    context->iface->_taken_transitions[3] += 1;
    context->delayedEnabled = 0;
    context->activeState = CLOSEDOORS;
  } else if (context->iface->_Elevator_local__Atrig || context->iface->_Elevator_local__Atrig1) {
    context->delayedEnabled = 0;
    context->activeState = RDYFORTAKEOFF1;
  } else {
    context->threadStatus = READY;
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry_state__EA_Done(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_EntryContext *context) {
  context->threadStatus = TERMINATED;
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry_state__EA_Init(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_EntryContext *context) {
  context->iface->stateID = 1;
  context->delayedEnabled = 0;
  context->activeState = __EA_DONE;
}

static void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_EntryContext *context) {
  while (context->threadStatus == RUNNING) {
    switch (context->activeState) {
      case __EA_INIT:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry_state__EA_Init(context);
                break;
      
      case __EA_DONE:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry_state__EA_Done(context);
                break;
      
    }
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1Context *context) {

  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry.activeState = __EA_INIT;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry.delayedEnabled = 0;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry.threadStatus = READY;
  context->activeState = OPENDOORSRUNNING;
}


static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_running(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1Context *context) {

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry.threadStatus != TERMINATED) {
    context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry.threadStatus = RUNNING;
  }
  

  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry(&context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry);

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry.threadStatus == TERMINATED) {
    context->delayedEnabled = 0;
    context->activeState = __EA_EXIT;
  } else {
  
      context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry.delayedEnabled = 1;
    context->threadStatus = READY;
  }

}

static void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1Context *context) {
  while (context->threadStatus == RUNNING) {
    switch (context->activeState) {
      case OPENDOORS:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors(context);
        // Superstate: intended fall-through 
      case OPENDOORSRUNNING:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_running(context);
        break;
      
      case WAIT:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateWait(context);
                break;
      
      case CLOSEDOORS:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors(context);
        // Superstate: intended fall-through 
      case CLOSEDOORSRUNNING:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_running(context);
        break;
      
      case RDYFORTAKEOFF1:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateRdyFortakeoff1(context);
                break;
      
      case __EA_EXIT:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_state__EA_Exit(context);
                break;
      
      case __EA_EXIT1:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_state__EA_Exit1(context);
                break;
      
    }
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1Context *context) {

  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1.activeState = OPENDOORS;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1.delayedEnabled = 0;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1.threadStatus = READY;

  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl.activeState = _ARUN;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl.delayedEnabled = 0;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl.threadStatus = READY;
  context->activeState = __EA_MAIN1RUNNING;
}


static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_running(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1Context *context) {

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1.threadStatus != TERMINATED) {
    context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1.threadStatus = RUNNING;
  }
  

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl.threadStatus != TERMINATED) {
    context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl.threadStatus = RUNNING;
  }
  

  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1(&context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1);

  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl(&context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl);

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1.threadStatus == TERMINATED && 
      context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl.threadStatus == TERMINATED) {
    context->delayedEnabled = 0;
    context->activeState = __EA_DONE5;
  } else {
  
      context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1.delayedEnabled = 1;
      context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl.delayedEnabled = 1;
    context->threadStatus = READY;
  }

}

static void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1Context *context) {
  while (context->threadStatus == RUNNING) {
    switch (context->activeState) {
      case __EA_MAIN1:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main(context);
        // Superstate: intended fall-through 
      case __EA_MAIN1RUNNING:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_running(context);
        break;
      
      case __EA_INIT4:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Init(context);
                break;
      
      case __EA_DONE5:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Done(context);
                break;
      
      case __EA_C:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_C(context);
                break;
      
      case __EA_C1:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_C1(context);
                break;
      
    }
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context *context) {

  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.activeState = __EA_INIT4;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.delayedEnabled = 0;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.threadStatus = READY;
  context->activeState = IDLERUNNING;
}


static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_running(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context *context) {

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.threadStatus != TERMINATED) {
    context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.threadStatus = RUNNING;
  }
  

  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1(&context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1);

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.threadStatus == TERMINATED) {
    context->delayedEnabled = 0;
    context->activeState = _AC;
  } else {
  
      context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.delayedEnabled = 1;
    context->threadStatus = READY;
  }

}

static void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0(Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context *context) {
  while (context->threadStatus == RUNNING) {
    switch (context->activeState) {
      case IDLE:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle(context);
        // Superstate: intended fall-through 
      case IDLERUNNING:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_running(context);
        break;
      
      case MOVINGUP:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp(context);
        // Superstate: intended fall-through 
      case MOVINGUPRUNNING:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_running(context);
        break;
      
      case MOVINGDOWN:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown(context);
        // Superstate: intended fall-through 
      case MOVINGDOWNRUNNING:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_running(context);
        break;
      
      case _AC:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_state_AC(context);
                break;
      
      case __EA_INIT10:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_state__EA_Init(context);
                break;
      
      case __EA_EXIT2:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_state__EA_Exit2(context);
                break;
      
      case __EA_EXIT3:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_state__EA_Exit3(context);
                break;
      
    }
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main(Elevator_region__EA_Entry_state__EA_Main_region_mainContext *context) {

  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.activeState = __EA_INIT10;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.delayedEnabled = 0;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.threadStatus = READY;
  context->activeState = _MAINRUNNING;
}


static inline void Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_running(Elevator_region__EA_Entry_state__EA_Main_region_mainContext *context) {

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.threadStatus != TERMINATED) {
    context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.threadStatus = RUNNING;
  }
  

  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0(&context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0);


  context->Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.delayedEnabled = 1;
  context->threadStatus = READY;

}

static void Elevator_region__EA_Entry_state__EA_Main_region_main(Elevator_region__EA_Entry_state__EA_Main_region_mainContext *context) {
  while (context->threadStatus == RUNNING) {
    switch (context->activeState) {
      case _MAIN:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main(context);
        // Superstate: intended fall-through 
      case _MAINRUNNING:
        Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_running(context);
        break;
      
    }
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_During_state_S(Elevator_region__EA_Entry_state__EA_Main_region_DuringContext *context) {
  if (context->delayedEnabled) {
    context->delayedEnabled = 0;
    context->activeState = _I;
  } else {
    context->threadStatus = READY;
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main_region_During_state_I(Elevator_region__EA_Entry_state__EA_Main_region_DuringContext *context) {
  context->iface->moveUp = 0;
  context->iface->moveDown = 0;
  context->delayedEnabled = 0;
  context->activeState = _S;
}

static void Elevator_region__EA_Entry_state__EA_Main_region_During(Elevator_region__EA_Entry_state__EA_Main_region_DuringContext *context) {
  while (context->threadStatus == RUNNING) {
    switch (context->activeState) {
      case _I:
        Elevator_region__EA_Entry_state__EA_Main_region_During_state_I(context);
                break;
      
      case _S:
        Elevator_region__EA_Entry_state__EA_Main_region_During_state_S(context);
                break;
      
    }
  }
}

static inline void Elevator_region__EA_Entry_state__EA_Main(Elevator_region__EA_EntryContext *context) {

  context->Elevator_region__EA_Entry_state__EA_Main_region_During.activeState = _I;
  context->Elevator_region__EA_Entry_state__EA_Main_region_During.delayedEnabled = 0;
  context->Elevator_region__EA_Entry_state__EA_Main_region_During.threadStatus = READY;

  context->Elevator_region__EA_Entry_state__EA_Main_region_main.activeState = _MAIN;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main.delayedEnabled = 0;
  context->Elevator_region__EA_Entry_state__EA_Main_region_main.threadStatus = READY;
  context->activeState = __EA_MAINRUNNING;
}


static inline void Elevator_region__EA_Entry_state__EA_Main_running(Elevator_region__EA_EntryContext *context) {

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_During.threadStatus != TERMINATED) {
    context->Elevator_region__EA_Entry_state__EA_Main_region_During.threadStatus = RUNNING;
  }
  

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_main.threadStatus != TERMINATED) {
    context->Elevator_region__EA_Entry_state__EA_Main_region_main.threadStatus = RUNNING;
  }
  

  Elevator_region__EA_Entry_state__EA_Main_region_During(&context->Elevator_region__EA_Entry_state__EA_Main_region_During);

  Elevator_region__EA_Entry_state__EA_Main_region_main(&context->Elevator_region__EA_Entry_state__EA_Main_region_main);

  if (context->Elevator_region__EA_Entry_state__EA_Main_region_During.threadStatus == TERMINATED && 
      context->Elevator_region__EA_Entry_state__EA_Main_region_main.threadStatus == TERMINATED) {
    context->delayedEnabled = 0;
    context->activeState = __EA_DONE12;
  } else {
  
      context->Elevator_region__EA_Entry_state__EA_Main_region_During.delayedEnabled = 1;
      context->Elevator_region__EA_Entry_state__EA_Main_region_main.delayedEnabled = 1;
    context->threadStatus = READY;
  }

}

static void Elevator_region__EA_Entry(Elevator_region__EA_EntryContext *context) {
  while (context->threadStatus == RUNNING) {
    switch (context->activeState) {
      case __EA_MAIN:
        Elevator_region__EA_Entry_state__EA_Main(context);
        // Superstate: intended fall-through 
      case __EA_MAINRUNNING:
        Elevator_region__EA_Entry_state__EA_Main_running(context);
        break;
      
      case __EA_INIT11:
        Elevator_region__EA_Entry_state__EA_Init(context);
                break;
      
      case __EA_DONE12:
        Elevator_region__EA_Entry_state__EA_Done(context);
                break;
      
    }
  }
}

static inline void Elevator(TickData *context) {

  if (context->Elevator_region__EA_Entry.threadStatus != TERMINATED) {
    context->Elevator_region__EA_Entry.threadStatus = RUNNING;
  }
  

  Elevator_region__EA_Entry(&context->Elevator_region__EA_Entry);


  context->Elevator_region__EA_Entry.delayedEnabled = 1;
  context->threadStatus = READY;

}

void reset(TickData *context) {
  context->Elevator_region__EA_Entry.iface = &(context->iface);
  context->Elevator_region__EA_Entry.Elevator_region__EA_Entry_state__EA_Main_region_During.iface = &(context->iface);
  context->Elevator_region__EA_Entry.Elevator_region__EA_Entry_state__EA_Main_region_main.iface = &(context->iface);
  context->Elevator_region__EA_Entry.Elevator_region__EA_Entry_state__EA_Main_region_main.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.iface = &(context->iface);
  context->Elevator_region__EA_Entry.Elevator_region__EA_Entry_state__EA_Main_region_main.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.iface = &(context->iface);
  context->Elevator_region__EA_Entry.Elevator_region__EA_Entry_state__EA_Main_region_main.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1.iface = &(context->iface);
  context->Elevator_region__EA_Entry.Elevator_region__EA_Entry_state__EA_Main_region_main.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry.iface = &(context->iface);
  context->Elevator_region__EA_Entry.Elevator_region__EA_Entry_state__EA_Main_region_main.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry.iface = &(context->iface);
  context->Elevator_region__EA_Entry.Elevator_region__EA_Entry_state__EA_Main_region_main.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl.iface = &(context->iface);
  context->Elevator_region__EA_Entry.Elevator_region__EA_Entry_state__EA_Main_region_main.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry.iface = &(context->iface);
  context->Elevator_region__EA_Entry.Elevator_region__EA_Entry_state__EA_Main_region_main.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0.Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry.iface = &(context->iface);
  context->Elevator_region__EA_Entry.activeState = __EA_INIT11;
  context->Elevator_region__EA_Entry.threadStatus = READY;
  
  context->threadStatus = READY;
  context->delayedEnabled = 0;
}

void tick(TickData *context) {
  if (context->threadStatus == TERMINATED) return;
  
  Elevator(context);
  context->delayedEnabled = 1;
}

