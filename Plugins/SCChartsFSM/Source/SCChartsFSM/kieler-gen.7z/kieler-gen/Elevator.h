/*
 * Automatically generated C code by
 * KIELER SCCharts - The Key to Efficient Modeling
 *
 * http://rtsys.informatik.uni-kiel.de/kieler
 */
#ifndef _ELEVATOR_H_
#define _ELEVATOR_H_

// The chosen scheduling regime (IUR) uses four states to maintain the statuses of threads."),
typedef enum {
  TERMINATED,
  RUNNING,
  READY,
  PAUSING
} ThreadStatus;

// Interface
typedef struct {
  char up; // Input
  char down; // Input
  char mooving;
  int stateID; // Output
  int currecntFloor; // Input
  int targetFloor; // Input
  int _taken_transitions[7];
  char doorOpen; // Input
  char moveUp; // Output
  char moveDown; // Output
  char _Elevator_local__Tterm;
  char _Elevator_local__Atrig;
  char _Elevator_local__Atrig1;
} Iface;

 
// This enum contains all states of the __EA_Entry region
typedef enum {
    __EA_INIT8, __EA_DONE9, __EA_C4, __EA_C5
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_EntryStates;

// The thread data of __EA_Entry
typedef struct {
  ThreadStatus threadStatus; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_EntryStates activeState; 
  char delayedEnabled; 
  Iface* iface; 
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_EntryContext;
 
// This enum contains all states of the __EA_Entry region
typedef enum {
    __EA_INIT6, __EA_DONE7, __EA_C2, __EA_C3
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_EntryStates;

// The thread data of __EA_Entry
typedef struct {
  ThreadStatus threadStatus; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_EntryStates activeState; 
  char delayedEnabled; 
  Iface* iface; 
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_EntryContext;
 
// This enum contains all states of the _ACtrl region
typedef enum {
    _ARUN, _ADONE
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrlStates;

// The thread data of _ACtrl
typedef struct {
  ThreadStatus threadStatus; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrlStates activeState; 
  char delayedEnabled; 
  Iface* iface; 
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrlContext;
 
// This enum contains all states of the __EA_Entry region
typedef enum {
    __EA_INIT2, __EA_DONE3
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_EntryStates;

// The thread data of __EA_Entry
typedef struct {
  ThreadStatus threadStatus; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_EntryStates activeState; 
  char delayedEnabled; 
  Iface* iface; 
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_EntryContext;
 
// This enum contains all states of the __EA_Entry region
typedef enum {
    __EA_INIT, __EA_DONE
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_EntryStates;

// The thread data of __EA_Entry
typedef struct {
  ThreadStatus threadStatus; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_EntryStates activeState; 
  char delayedEnabled; 
  Iface* iface; 
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_EntryContext;
 
// This enum contains all states of the  region
typedef enum {
    OPENDOORS, OPENDOORSRUNNING, WAIT, CLOSEDOORS, CLOSEDOORSRUNNING, RDYFORTAKEOFF1, __EA_EXIT, __EA_EXIT1
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1States;

// The thread data of 
typedef struct {
  ThreadStatus threadStatus; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1States activeState; 
  char delayedEnabled; 
  Iface* iface; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_EntryContext Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateOpenDoors_region__EA_Entry;
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_EntryContext Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1_stateCloseDoors_region__EA_Entry;
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1Context;
 
// This enum contains all states of the __EA_Entry1 region
typedef enum {
    __EA_MAIN1, __EA_MAIN1RUNNING, __EA_INIT4, __EA_DONE5, __EA_C, __EA_C1
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1States;

// The thread data of __EA_Entry1
typedef struct {
  ThreadStatus threadStatus; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1States activeState; 
  char delayedEnabled; 
  Iface* iface; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1Context Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_regionR1;
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrlContext Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1_state__EA_Main_region_ACtrl;
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1Context;
 
// This enum contains all states of the  region
typedef enum {
    IDLE, IDLERUNNING, MOVINGUP, MOVINGUPRUNNING, MOVINGDOWN, MOVINGDOWNRUNNING, _AC, __EA_INIT10, __EA_EXIT2, __EA_EXIT3
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0States;

// The thread data of 
typedef struct {
  ThreadStatus threadStatus; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0States activeState; 
  char delayedEnabled; 
  Iface* iface; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1Context Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateIdle_region__EA_Entry1;
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_EntryContext Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingUp_region__EA_Entry;
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_EntryContext Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0_stateMovingDown_region__EA_Entry;
} Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context;
 
// This enum contains all states of the _main region
typedef enum {
    _MAIN, _MAINRUNNING
} Elevator_region__EA_Entry_state__EA_Main_region_mainStates;

// The thread data of _main
typedef struct {
  ThreadStatus threadStatus; 
  Elevator_region__EA_Entry_state__EA_Main_region_mainStates activeState; 
  char delayedEnabled; 
  Iface* iface; 
  Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0Context Elevator_region__EA_Entry_state__EA_Main_region_main_state_main_regionR0;
} Elevator_region__EA_Entry_state__EA_Main_region_mainContext;
 
// This enum contains all states of the _During region
typedef enum {
    _I, _S
} Elevator_region__EA_Entry_state__EA_Main_region_DuringStates;

// The thread data of _During
typedef struct {
  ThreadStatus threadStatus; 
  Elevator_region__EA_Entry_state__EA_Main_region_DuringStates activeState; 
  char delayedEnabled; 
  Iface* iface; 
} Elevator_region__EA_Entry_state__EA_Main_region_DuringContext;
 
// This enum contains all states of the __EA_Entry region
typedef enum {
    __EA_MAIN, __EA_MAINRUNNING, __EA_INIT11, __EA_DONE12
} Elevator_region__EA_EntryStates;

// The thread data of __EA_Entry
typedef struct {
  ThreadStatus threadStatus; 
  Elevator_region__EA_EntryStates activeState; 
  char delayedEnabled; 
  Iface* iface; 
  Elevator_region__EA_Entry_state__EA_Main_region_DuringContext Elevator_region__EA_Entry_state__EA_Main_region_During;
  Elevator_region__EA_Entry_state__EA_Main_region_mainContext Elevator_region__EA_Entry_state__EA_Main_region_main;
} Elevator_region__EA_EntryContext;

// Root level data of the program
typedef struct {
  Iface iface;
  ThreadStatus threadStatus;
  char delayedEnabled;
  
  Elevator_region__EA_EntryContext Elevator_region__EA_Entry;
} TickData;



void reset(TickData *context);
void tick(TickData *context);

#endif